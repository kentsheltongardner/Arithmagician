import Point from './point.js'
import * as I from './images.js'
import * as C from './constants.js'
import World from './world.js'

export default class Editor {
    private _focus:             Point
    private _mousePoint:        Point
    private _gamePoint:         Point
    private _inspectCell:       Point
    private _scale:             number
    private _right:             boolean
    private _left:              boolean
    private _space:             boolean
    private _world:             World

    private _canvas:            HTMLCanvasElement
    private _context:           CanvasRenderingContext2D
    private _dataInput:         HTMLInputElement
    private _portInput:         HTMLInputElement
    private _actionSelect:      HTMLSelectElement
    private _layerSelect:       HTMLSelectElement
    private _buildIcons:        NodeListOf<HTMLElement>
    private _buildGrids:        HTMLCollectionOf<HTMLElement>
    private _inspector:         HTMLElement

    constructor() {
        this._focus             = new Point(C.WorldWidthCells / 2, C.WorldHeightCells / 2)
        this._scale             = C.CellSizePixels
        this._mousePoint        = new Point(0, 0)
        this._gamePoint         = new Point(0, 0)
        this._inspectCell       = new Point(0, 0)
        this._right             = false
        this._left              = false
        this._space             = false
        this._world             = new World()

        this._canvas            = <HTMLCanvasElement>document.getElementById('editor-canvas')
        this._context           = <CanvasRenderingContext2D>this._canvas.getContext('2d')
        this._dataInput         = <HTMLInputElement>document.getElementById('data-input')
        this._portInput         = <HTMLInputElement>document.getElementById('port-input')
        this._actionSelect      = <HTMLSelectElement>document.getElementById('action-select')
        this._layerSelect       = <HTMLSelectElement>document.getElementById('layer-select')
        this._buildIcons        = <NodeListOf<HTMLElement>>document.querySelectorAll('.build-icon')
        this._buildGrids        = <HTMLCollectionOf<HTMLElement>>document.getElementsByClassName('build-grid')
        this._inspector         = <HTMLElement>document.getElementById('inspector')

        this._canvas.addEventListener('mousedown',      e => this.mouseDown(e))
        this._canvas.addEventListener('mousemove',      e => this.mouseMove(e))
        this._canvas.addEventListener('mouseup',        e => this.mouseUp(e))
        this._canvas.addEventListener('mouseleave',     e => this.mouseLeave(e))
        this._canvas.addEventListener('wheel',          e => this.mouseWheel(e))
        this._canvas.addEventListener('contextmenu',    e => this.contextMenu(e))

        window.addEventListener('keydown',              e => this.keyDown(e))
        window.addEventListener('keyup',                e => this.keyUp(e))

        this._actionSelect.addEventListener('change',   () => { this.actionSelected() })
        this._layerSelect.addEventListener('change',    () => { this.layerSelected() })
        this._dataInput.addEventListener('input',       () => { this.dataInputReceived() })
        this._portInput.addEventListener('input',       () => { this.portInputReceived() })
        this._dataInput.addEventListener('focusout',    () => { this.dataInputFocusOut() })
        this._portInput.addEventListener('focusout',    () => { this.portInputFocusOut() })


        for (const buildIcon of this._buildIcons) {
            buildIcon.addEventListener('click', () => { this.buildIconSelected(buildIcon) })
        }

        this.loop()
    }

// #     #  #######  
// #     #     #     
// #     #     #     
// #     #     #     
// #     #     #     
// #     #     #     
//  #####   #######  

    private action(): number {
        return C.StringToAction[this._actionSelect.value]
    }
    private layer(): number {
        return C.StringToLayer[this._layerSelect.value]
    }
    private type(): number {
        const activeBuildGrid   = this.activeBuildGrid()
        const selectedBuildIcon = <HTMLElement>activeBuildGrid.querySelector('.build-icon.selected')
        const buildType         = <string>selectedBuildIcon.dataset.type
        return C.StringToType[buildType]
    }
    private activeBuildIcons(): NodeListOf<HTMLElement> {
        const activeBuildGrid = this.activeBuildGrid()
        return <NodeListOf<HTMLElement>>activeBuildGrid.querySelectorAll('.build-icon')
    }
    private activeBuildGrid(): HTMLElement {
        return <HTMLElement>document.querySelector('.build-grid.active')
    }
    private buildIconSelected(selectedBuildIcon: HTMLElement) {
        const activeBuildIcons = this.activeBuildIcons()
        for (const activeBuildIcon of activeBuildIcons) {
            activeBuildIcon.classList.remove('selected')
        }
        selectedBuildIcon.classList.add('selected')
    }
    private actionSelected() {
        if (C.StringToAction[this._actionSelect.value] === C.ActionInspect) {
            this._inspector.style.display   = 'flex'
            const x                         = this._inspectCell.x
            const y                         = this._inspectCell.y
            this._dataInput.value           = this._world.objectData[x][y]
            this._portInput.value           = this._world.objectPorts[x][y].toString(2).padStart(8, '0')
        } else {
            this._inspector.style.display = 'none'
        }
    }
    private layerSelected() {
        const selectedIndex     = this._layerSelect.selectedIndex
        const selectedOption    = this._layerSelect.options[selectedIndex]
        const gridId            = <string>selectedOption.dataset.grid
        const grid              = <HTMLElement>document.getElementById(gridId)
        for (const buildGrid of this._buildGrids) {
            buildGrid.classList.remove('active')
        }
        grid.classList.add('active')
    }
    private hideLayer(layer: number): boolean {
        const layerString = C.LayerToString[layer]
        const selector = `.hide-checkbox[data-layer=${layerString}]`
        const checkbox = <HTMLInputElement>document.querySelector(selector)
        return checkbox.checked
    }
    private highlightLayer(layer: number): boolean {
        const layerString = C.LayerToString[layer]
        const selector = `.highlight-checkbox[data-layer=${layerString}]`
        const checkbox = <HTMLInputElement>document.querySelector(selector)
        return checkbox.checked
    }

// #     #   #####   #     #   #####   #######  
// ##   ##  #     #  #     #  #     #  #        
// # # # #  #     #  #     #  #        #        
// #  #  #  #     #  #     #   #####   ####     
// #     #  #     #  #     #        #  #        
// #     #  #     #  #     #  #     #  #        
// #     #   #####    #####    #####   #######  

    private mouseDown(e: MouseEvent) {
        if (e.button === 0) {
            this._left = true
        } else if (e.button === 2) {
            this._right = true
        }

        // Panning (space) overrides selected action
        if (this._space) return

        switch (this.action()) {
            case C.ActionBuild: {
                if (this._left) {
                    this.build()
                } else if (this._right) {
                    this.erase()
                }
                break
            }
            case C.ActionConnect: {
                if (this._left) {
                    this.connect()
                } else if (this._right) {
                    this.disconnect()
                }
                break
            }
        }

        if (this._left) {
            this.inspect()
        }

        // At the end of this function, a single action should happen
    }
    private mouseMove(e: MouseEvent) {
        this._mousePoint = new Point(e.offsetX, e.offsetY)
        let gamePoint = this.gamePoint(this._mousePoint)

        if (this._space && (this._left || this._right )) {
            const dragVector = this._gamePoint.differenceVector(gamePoint)
            this._focus = this._focus.addVector(dragVector)
        } else {

            switch (this.action()) {
                case C.ActionBuild: {
                    if (this._left) {
                        this.build()
                    } else if (this._right) {
                        this.erase()
                    }
                    break
                }
                case C.ActionConnect: {
                    if (this._left) {
                        this.connect()
                    } else if (this._right) {
                        this.disconnect()
                    }
                    break
                }
            }

            if (this._left) {
                this.inspect()
            }
        }

        this._gamePoint = this.gamePoint(this._mousePoint)

        // At the end of this function, a single action should happen
    }
    private mouseUp(e: MouseEvent) {
        if (e.button === 0) {
            this._left = false
        } else if (e.button === 2) {
            this._right = false
        }
    }
    private mouseLeave(e: MouseEvent) {
        this._left = this._right = false
    }

    private mouseWheel(e: WheelEvent) {
        const direction = Math.sign(e.deltaY)
        if (direction === 1) {
            this._scale *= C.ZoomOutFactor
            this._focus.x = this._gamePoint.x - C.ZoomInFactor * (this._gamePoint.x - this._focus.x)
            this._focus.y = this._gamePoint.y - C.ZoomInFactor * (this._gamePoint.y - this._focus.y)
        } else {
            this._scale *= C.ZoomInFactor
            this._focus.x = this._gamePoint.x - C.ZoomOutFactor * (this._gamePoint.x - this._focus.x)
            this._focus.y = this._gamePoint.y - C.ZoomOutFactor * (this._gamePoint.y - this._focus.y)
        }
    }
    private contextMenu(e: MouseEvent) {
        e.preventDefault()
        e.stopPropagation()
    }

// #     #  #######  #     #   #####   
// #    #   #         #   #   #     #  
// #   #    #          # #    #        
// ####     ####        #      #####   
// #   #    #           #           #  
// #    #   #           #     #     #  
// #     #  #######     #      #####   

    private keyDown(e: KeyboardEvent) {
        switch (e.code) {
            case 'Space': {
                this._space = true
                break
            }
            case 'Escape': {
                this._dataInput.blur()
                this._portInput.blur()
                break
            }
        }

        if (document.activeElement?.nodeName === 'INPUT') return
        switch (e.code) {
            case 'KeyB': {
                this._actionSelect.value = C.ActionToString[C.ActionBuild]
                this._actionSelect.dispatchEvent(new Event('change'))
                break
            }
            case 'KeyC': {
                this._actionSelect.value = C.ActionToString[C.ActionConnect]
                this._actionSelect.dispatchEvent(new Event('change'))
                break
            }
            case 'KeyI': {
                this._actionSelect.value = C.ActionToString[C.ActionInspect]
                this._actionSelect.dispatchEvent(new Event('change'))
                break
            }
            case 'KeyS': {
                this._actionSelect.value = C.ActionToString[C.ActionSelect]
                this._actionSelect.dispatchEvent(new Event('change'))
                break
            }
            case 'KeyF': {
                this._layerSelect.value = C.LayerToString[C.LayerFloor]
                this._layerSelect.dispatchEvent(new Event('change'))
                break
            }
            case 'KeyO': {
                this._layerSelect.value = C.LayerToString[C.LayerObject]
                this._layerSelect.dispatchEvent(new Event('change'))
                break
            }
            case 'KeyR': {
                this._layerSelect.value = C.LayerToString[C.LayerRoof]
                this._layerSelect.dispatchEvent(new Event('change'))
                break
            }
        }
    } 
    private keyUp(e: KeyboardEvent) {
        switch (e.code) {
            case 'Space': { 
                this._space = false
                break
            }
        }
    }

// ######   #     #  #######  #        ######   
// #     #  #     #     #     #        #     #  
// #     #  #     #     #     #        #     #  
// ######   #     #     #     #        #     #  
// #     #  #     #     #     #        #     #  
// #     #  #     #     #     #        #     #  
// ######    #####   #######  #######  ######   

    private build() {
        const cellPoint = this.cellPoint(this._gamePoint)
        if (!C.InnerWorldRectCells.contains(cellPoint)) return
        
        const type = this.type()
        switch (this.layer()) {
            case C.LayerFloor: {
                this.buildCell(type, cellPoint, this._world.floor, this._world.floorConnections)
                break
            }
            case C.LayerObject: {
                this._world.objectData[cellPoint.x][cellPoint.y] = ''
                this._world.objectPorts[cellPoint.x][cellPoint.y] = 0b00000000
                this._world.objectFlags[cellPoint.x][cellPoint.y] = 0b00000000
                this.buildCell(type, cellPoint, this._world.objects, this._world.objectConnections)
                if (type === C.TypeUnaryOperator) {
                    this._world.objectPorts[cellPoint.x][cellPoint.y] = 0b01001100
                    const words = Array.from(C.UnaryOperatorStrings)
                    const word = words[Math.floor(Math.random() * words.length)]
                    this._world.objectData[cellPoint.x][cellPoint.y] = word
                }
                if (type === C.TypeBinaryOperator) {
                    this._world.objectPorts[cellPoint.x][cellPoint.y] = 0b00100111
                    const words = Array.from(C.BinaryOperatorStrings)
                    const word = words[Math.floor(Math.random() * words.length)]
                    this._world.objectData[cellPoint.x][cellPoint.y] = word
                }
                if (type === C.TypeDefinition) {
                    const variable = String.fromCharCode(C.CharCodeA + Math.floor(Math.random() * 26))
                    this._world.objectPorts[cellPoint.x][cellPoint.y] = 0b00000001
                    this._world.objectData[cellPoint.x][cellPoint.y] = variable
                }
                if (type === C.TypeGate) {
                    this._world.objectData[cellPoint.x][cellPoint.y] = '1/21'
                }
                if (type === C.TypeVariable) {
                    const variable = String.fromCharCode(C.CharCodeA + Math.floor(Math.random() * 26))
                    this._world.objectPorts[cellPoint.x][cellPoint.y] = 0b00000101
                    this._world.objectData[cellPoint.x][cellPoint.y] = variable
                }
                if (type === C.TypeConstant) {
                    this._world.objectPorts[cellPoint.x][cellPoint.y] = 0b00000101
                    this._world.objectData[cellPoint.x][cellPoint.y] = '1'
                }
                break
            }
            case C.LayerRoof: {
                this.buildCell(type, cellPoint, this._world.roof, this._world.roofConnections)
                break
            }
        }
    }
    private buildCell(type: number, cellPoint: Point, types: Array<Uint8Array>, connections: Array<Uint8Array>) {
        const x = cellPoint.x
        const y = cellPoint.y

        if (types[x][y] !== type) this.eraseCell(cellPoint, types, connections)
        
        types[x][y] = type

        switch (C.TypeToTileset[type]) {
            case C.TilesetConnected:
                const e = x + 1
                const s = y + 1
                const w = x - 1
                const n = y - 1
        
                if (types[e][y] === type) {
                    connections[x][y] |= C.BitsEast
                    connections[e][y] |= C.BitsWest
                }
                if (types[x][s] === type) {
                    connections[x][y] |= C.BitsSouth
                    connections[x][s] |= C.BitsNorth
                }
                if (types[w][y] === type) {
                    connections[x][y] |= C.BitsWest
                    connections[w][y] |= C.BitsEast
                }
                if (types[x][n] === type) {
                    connections[x][y] |= C.BitsNorth
                    connections[x][n] |= C.BitsSouth
                }
        
                if (types[e][y]     === type 
                    && types[e][s]  === type 
                    && types[x][s]  === type
                    && (connections[e][y] & C.BitsSouth)    === C.BitsSouth 
                    && (connections[x][s] & C.BitsEast)     === C.BitsEast) {
                    connections[x][y] |= C.BitsSoutheast
                    connections[e][y] |= C.BitsSouthwest
                    connections[x][s] |= C.BitsNortheast
                    connections[e][s] |= C.BitsNorthwest
                }
                if (types[w][y]     === type 
                    && types[w][s]  === type 
                    && types[x][s]  === type
                    && (connections[w][y] & C.BitsSouth)    === C.BitsSouth 
                    && (connections[x][s] & C.BitsWest)     === C.BitsWest) {
                    connections[x][y] |= C.BitsSouthwest
                    connections[w][y] |= C.BitsSoutheast
                    connections[x][s] |= C.BitsNorthwest
                    connections[w][s] |= C.BitsNortheast
                }
                if (types[w][y]     === type 
                    && types[w][n]  === type 
                    && types[x][n]  === type
                    && (connections[w][y] & C.BitsNorth)    === C.BitsNorth 
                    && (connections[x][n] & C.BitsWest)     === C.BitsWest) {
                    connections[x][y] |= C.BitsNorthwest
                    connections[w][y] |= C.BitsNortheast
                    connections[x][n] |= C.BitsSouthwest
                    connections[w][n] |= C.BitsSoutheast
                }
                if (types[e][y]     === type 
                    && types[e][n]  === type 
                    && types[x][n]  === type
                    && (connections[e][y] & C.BitsNorth)    === C.BitsNorth 
                    && (connections[x][n] & C.BitsEast)     === C.BitsEast) {
                    connections[x][y] |= C.BitsNortheast
                    connections[e][y] |= C.BitsNorthwest
                    connections[x][n] |= C.BitsSoutheast
                    connections[e][n] |= C.BitsSouthwest
                }
            break
        }
    }

    private erase() {
        const cellPoint = this.cellPoint(this._gamePoint)
        if (!C.InnerWorldRectCells.contains(cellPoint)) return

        switch (this.layer()) {
            case C.LayerFloor: {
                this.eraseCell(cellPoint, this._world.floor, this._world.floorConnections)
                break
            }
            case C.LayerObject: {
                this.eraseCell(cellPoint, this._world.objects, this._world.objectConnections)
                this._world.objectData[cellPoint.x][cellPoint.y] = ''
                this._world.objectPorts[cellPoint.x][cellPoint.y] = 0b00000000
                this._world.objectFlags[cellPoint.x][cellPoint.y] = 0b00000000
                break
            }
            case C.LayerRoof: {
                this.eraseCell(cellPoint, this._world.roof, this._world.roofConnections)
                break
            }
        }
    }
    private eraseCell(cellPoint: Point, types: Array<Uint8Array>, connections: Array<Uint8Array>) {
        const x             = cellPoint.x
        const y             = cellPoint.y
        const e             = x + 1
        const s             = y + 1
        const w             = x - 1
        const n             = y - 1
        types[x][y]         = C.TypeEmpty
        connections[x][y]   = C.BitsNone
        connections[e][y]   &= ~(C.BitsWest  | C.BitsSouthwest | C.BitsNorthwest)
        connections[x][s]   &= ~(C.BitsNorth | C.BitsNortheast | C.BitsNorthwest)
        connections[w][y]   &= ~(C.BitsEast  | C.BitsSoutheast | C.BitsNortheast)
        connections[x][n]   &= ~(C.BitsSouth | C.BitsSoutheast | C.BitsSouthwest)
        connections[e][s]   &= ~C.BitsNorthwest
        connections[w][s]   &= ~C.BitsNortheast
        connections[w][n]   &= ~C.BitsSoutheast
        connections[e][n]   &= ~C.BitsSouthwest
    }

//  #####    #####   #     #  #     #  #######   #####   #######  
// #     #  #     #  ##    #  ##    #  #        #     #     #     
// #        #     #  # #   #  # #   #  #        #           #     
// #        #     #  #  #  #  #  #  #  ####     #           #     
// #        #     #  #   # #  #   # #  #        #           #     
// #     #  #     #  #    ##  #    ##  #        #     #     #     
//  #####    #####   #     #  #     #  #######   #####      #     

    private connect() {
        const cellPoint = this.cellPoint(this._gamePoint)
        if (!C.InnerWorldRectCells.contains(cellPoint)) return

        switch (this.layer()) {
            case C.LayerFloor: {
                this.connectCells(cellPoint, this._world.floor, this._world.floorConnections)
                break
            }
            case C.LayerObject: {
                this.connectCells(cellPoint, this._world.objects, this._world.objectConnections)
                break
            }
            case C.LayerRoof: {
                this.connectCells(cellPoint, this._world.roof, this._world.roofConnections)
                break
            }
        }
    }
    private connectCells(cellPoint: Point, types: Array<Uint8Array>, connections: Array<Uint8Array>) {
        let x           = cellPoint.x
        let y           = cellPoint.y

        switch (C.TypeToTileset[types[x][y]]) {
            case C.TilesetConnected:
            const gamePoint = this._gamePoint
            let cellX       = gamePoint.x - cellPoint.x
            let cellY       = gamePoint.y - cellPoint.y
            
            if (cellX < C.ConnectionScalar) {
                x--
                cellX += 1.0
            }
            if (cellY < C.ConnectionScalar) {
                y--
                cellY += 1.0
            }

            const type  = types[x][y]
            const e     = x + 1
            const s     = y + 1
            const point = new Point(cellX, cellY)

            const distanceEast = point.distance(new Point(1, 0.5))
            if (types[e][y] === type && distanceEast < C.ConnectionScalar) {
                connections[x][y] |= C.BitsEast
                connections[e][y] |= C.BitsWest
                return
            }
            const distanceSouth = point.distance(new Point(0.5, 1))
            if (types[x][s] === type && distanceSouth < C.ConnectionScalar) {
                connections[x][y] |= C.BitsSouth
                connections[x][s] |= C.BitsNorth
                return
            }
            const distanceSoutheast = point.distance(new Point(1, 1))
            if (types[e][y]     === type
                && types[x][s]  === type
                && types[e][s]  === type
                && distanceSoutheast < C.ConnectionScalar) {
                connections[x][y] |= (C.BitsEast | C.BitsSouth | C.BitsSoutheast)
                connections[e][y] |= (C.BitsWest | C.BitsSouth | C.BitsSouthwest)
                connections[x][s] |= (C.BitsEast | C.BitsNorth | C.BitsNortheast)
                connections[e][s] |= (C.BitsWest | C.BitsNorth | C.BitsNorthwest)
            }
            break
        }
    }

    private disconnect() {
        const cellPoint = this.cellPoint(this._gamePoint)
        if (!C.InnerWorldRectCells.contains(cellPoint)) return

        switch (this.layer()) {
            case C.LayerFloor: {
                this.disconnectCells(cellPoint, this._world.floorConnections)
                break
            }
            case C.LayerObject: {
                this.disconnectCells(cellPoint, this._world.objectConnections)
                break
            }
            case C.LayerRoof: {
                this.disconnectCells(cellPoint, this._world.roofConnections)
                break
            }
        }
    }
    private disconnectCells(cellPoint: Point, connections: Array<Uint8Array>) {
        const gamePoint = this._gamePoint
        let x           = cellPoint.x
        let y           = cellPoint.y
        let cellX       = gamePoint.x - cellPoint.x
        let cellY       = gamePoint.y - cellPoint.y
        
        if (cellX < C.ConnectionScalar) {
            x--
            cellX += 1.0
        }
        if (cellY < C.ConnectionScalar) {
            y--
            cellY += 1.0
        }

        const e     = x + 1
        const s     = y + 1
        const w     = x - 1
        const n     = y - 1
        const point = new Point(cellX, cellY)

        const distanceEast = point.distance(new Point(1, 0.5))
        if (distanceEast < C.ConnectionScalar) {
            connections[x][y] &= ~(C.BitsNortheast | C.BitsEast | C.BitsSoutheast)
            connections[e][y] &= ~(C.BitsNorthwest | C.BitsWest | C.BitsSouthwest)
            connections[x][n] &= ~C.BitsSoutheast
            connections[x][s] &= ~C.BitsNortheast
            connections[e][n] &= ~C.BitsSouthwest
            connections[e][s] &= ~C.BitsNorthwest
            return
        }
        const distanceSouth = point.distance(new Point(0.5, 1))
        if (distanceSouth < C.ConnectionScalar) {
            connections[x][y] &= ~(C.BitsSoutheast | C.BitsSouth | C.BitsSouthwest)
            connections[x][s] &= ~(C.BitsNorthwest | C.BitsNorth | C.BitsNortheast)
            connections[e][y] &= ~C.BitsSouthwest
            connections[w][y] &= ~C.BitsSoutheast
            connections[e][s] &= ~C.BitsNorthwest
            connections[w][s] &= ~C.BitsNortheast
            return
        }
        const distanceSoutheast = point.distance(new Point(1, 1))
        if (distanceSoutheast < C.ConnectionScalar) {
            connections[x][y] &= ~C.BitsSoutheast
            connections[e][y] &= ~C.BitsSouthwest
            connections[x][s] &= ~C.BitsNortheast
            connections[e][s] &= ~C.BitsNorthwest
        }
    }

// #######  #     #   #####   ######   #######   #####   #######  
//    #     ##    #  #     #  #     #  #        #     #     #     
//    #     # #   #  #        #     #  #        #           #     
//    #     #  #  #   #####   ######   ####     #           #     
//    #     #   # #        #  #        #        #           #     
//    #     #    ##  #     #  #        #        #     #     #     
// #######  #     #   #####   #        #######   #####      #     
    
    private inspect() {
        this._inspectCell       = this.cellPoint(this._gamePoint)
        const x                 = this._inspectCell.x
        const y                 = this._inspectCell.y
        this._dataInput.value   = this._world.objectData[x][y]
        this._portInput.value   = this._world.objectPorts[x][y].toString(2).padStart(8, '0')
    }
    private inspectType(): number {
        const x = this._inspectCell.x
        const y = this._inspectCell.y
        return this._world.objects[x][y]
    }
    private dataInputReceived() {
        if (this.validData()) {
            this._dataInput.classList.remove('invalid')
            const x                         = this._inspectCell.x
            const y                         = this._inspectCell.y
            this._world.objectData[x][y]    = this._dataInput.value
        } else {
            this._dataInput.classList.add('invalid')
        }
    }
    private dataInputFocusOut() {
        const x                 = this._inspectCell.x
        const y                 = this._inspectCell.y
        this._dataInput.value   = this._world.objectData[x][y]
        this._dataInput.classList.remove('invalid')
    }
    private validData() {
        const value = this._dataInput.value
        switch (this.inspectType()) {
            case C.TypeDefinition: {
                return this.isValidVariable(value)
            }
            case C.TypeConstant: {
                return this.isValidBoolean(value)
                || this.isValidInteger(value)
                || this.isValidRational(value)
            }
            case C.TypeVariable: {
                return this.isValidVariable(value)
            }
            case C.TypeUnaryOperator: {
                return this.isValidUnaryOperator(value)
            }
            case C.TypeBinaryOperator: {
                return this.isValidBinaryOperator(value)
            }
            case C.TypeGate: {
                return this.isValidBoolean(value)
                || this.isValidVariable(value)
                || this.isValidInteger(value)
                || this.isValidRational(value)
            }
        }
        return value.length === 0
    }


    private portInputReceived() {
        if (this.validPort()) {
            this._portInput.classList.remove('invalid')
            const x                         = this._inspectCell.x
            const y                         = this._inspectCell.y
            this._world.objectPorts[x][y]   = parseInt(this._portInput.value, 2)
        } else {
            this._portInput.classList.add('invalid')
        }
    }
    private portInputFocusOut() {
        const x                 = this._inspectCell.x
        const y                 = this._inspectCell.y
        this._portInput.value   = this._world.objectPorts[x][y].toString(2).padStart(8, '0')
        this._portInput.classList.remove('invalid')
    }
    private validPort() {
        const value = this._portInput.value
        if (!/^[0-1]{8}$/.test(value)) {
            return false
        }
        const ports = parseInt(value, 2)

        switch (this.inspectType()) {
            case C.TypeDefinition: {
                return this.areValidDefinitionPorts(ports)
            }
            case C.TypeConstant: {
                return this.areValidConstantPorts(ports)
            }
            case C.TypeVariable: {
                return this.areValidVariablePorts(ports)
            }
            case C.TypeUnaryOperator: {
                return this.areValidUnaryOperatorPorts(ports)
            }
            case C.TypeBinaryOperator: {
                return this.areValidBinaryOperatorPorts(ports)
            }
        }
        return ports === 0
    }
    private areValidDefinitionPorts(ports: number) {
        return ports < 4
    }
    private areValidConstantPorts(ports: number) {
        return ports > 0 && ports < 16
    }
    private areValidVariablePorts(ports: number) {
        return ports > 0 && ports < 16
    }
    private areValidUnaryOperatorPorts(ports: number) {
        const counts = new Uint8Array(4)
        counts[ports & 0b00000011]++
        counts[(ports >> 2) & 0b00000011]++
        counts[(ports >> 4) & 0b00000011]++
        counts[(ports >> 6) & 0b00000011]++
        return counts[1] === 1 && counts[3] >= 1
    }
    private areValidBinaryOperatorPorts(ports: number) {
        const counts = new Uint8Array(4)
        counts[ports & 0b00000011]++
        counts[(ports >> 2) & 0b00000011]++
        counts[(ports >> 4) & 0b00000011]++
        counts[(ports >> 6) & 0b00000011]++
        return counts[1] === 1 && counts[2] === 1 && counts[3] >= 1
    }

    private isValidInteger(value: string) {
        return /^(0|-?[1-9]\d?)$/.test(value)
    }
    private isValidRational(value: string) {
        return /^(0|-?[1-9]\d?)\/[1-9]\d?$/.test(value)
    }
    private isValidBoolean(value: string) {
        return /^(true|false)$/.test(value)
    }
    private isValidVariable(value: string): boolean {
        return /^[a-z]$/.test(value)
    }
    private isValidUnaryOperator(value: string) {
        return C.UnaryOperatorStrings.has(value)
    }
    private isValidBinaryOperator(value: string) {
        return C.BinaryOperatorStrings.has(value)
    }
    private dataType(value: string) {
        if (value.length === 0)             return C.DataNone
        if (this.isValidBoolean(value))     return C.DataBoolean
        if (this.isValidVariable(value))    return C.DataVariable
        if (this.isValidInteger(value))     return C.DataInteger
        if (this.isValidRational(value))    return C.DataRational
        if (this.isValidUnaryOperator(value)
            || this.isValidBinaryOperator(value)) {
                return C.DataOperator
        }
        return C.DataGeneral
    }

// ######   #######  #     #  ######   #######  ######   
// #     #  #        ##    #  #     #  #        #     #  
// #     #  #        # #   #  #     #  #        #     #  
// ######   ####     #  #  #  #     #  ####     ######   
// #   #    #        #   # #  #     #  #        #   #    
// #    #   #        #    ##  #     #  #        #    #   
// #     #  #######  #     #  ######   #######  #     #  

    private loop() {
        this.render()
        requestAnimationFrame(() => this.loop())
    }
    private render() {
        this._canvas.width = this._canvas.offsetWidth
        this._canvas.height = this._canvas.offsetHeight
        this._context.imageSmoothingEnabled = false

        if (!this.hideLayer(C.LayerFloor)) {
            this.renderSimpleLayer(this._world.floor, this._world.floorConnections)
        }
        if (!this.hideLayer(C.LayerObject)) {
            this.renderObjects()
        }
        if (!this.hideLayer(C.LayerRoof)) {
            this.renderSimpleLayer(this._world.roof, this._world.roofConnections)
        }

        if (this.highlightLayer(C.LayerFloor)) {
            this.renderHighlights(this._world.floor)
        }
        if (this.highlightLayer(C.LayerObject)) {
            this.renderHighlights(this._world.objects)
        }
        if (this.highlightLayer(C.LayerRoof)) {
            this.renderHighlights(this._world.roof)
        }

        if (this.action() === C.ActionBuild) {
            this.renderHover()
        }
        if (this.action() === C.ActionConnect) {
            this.renderConnections()
        }
        if (this.action() === C.ActionInspect) {
            this.renderHover()
            this.renderInspector()
        }

        this.renderGrid()
        this.renderMouseCell()
    }
    private renderGrid() {
        const topLeft   = this.canvasPoint(new Point(0, 0))
        const bottom    = topLeft.y + C.WorldHeightCells * this._scale
        const right     = topLeft.x + C.WorldWidthCells * this._scale
        this._context.strokeStyle = '#ffffff40'
        this._context.lineWidth = this._scale * 0.03125
        this._context.beginPath()
        for (let i = topLeft.y; i <= bottom; i += this._scale) {
            this._context.moveTo(topLeft.x, i)
            this._context.lineTo(right, i)
        }
        for (let i = topLeft.x; i <= right; i += this._scale) {
            this._context.moveTo(i, topLeft.y)
            this._context.lineTo(i, bottom)
        }
        this._context.stroke()
    }
    private renderMouseCell() {
        this._context.fillStyle = '#ffffff80'
        this._context.font = "20px sans-serif"
        const cell = this.cellPoint(this._gamePoint)
        this._context.fillText(`${cell.x}, ${cell.y}`, 10, this._canvas.offsetHeight - 15)
    }

    private renderSimpleLayer(types: Array<Uint8Array>, connections: Array<Uint8Array>, ) {
        for (let i = 0; i < C.WorldWidthCells; i++) {
            for (let j = 0; j < C.WorldHeightCells; j++) {
                const type = types[i][j]
                if (type === C.TypeEmpty) continue

                const point         = new Point(i, j)
                const canvasPoint   = this.canvasPoint(point)
                const tileset       = I.TypeToTileset.get(type)!

                switch (C.TypeToTileset[type]) {
                    case C.TilesetConnected: {
                        this._context.drawImage(tileset, 
                            connections[i][j] * C.CellSizePixels, 0, C.CellSizePixels, C.CellSizePixels, 
                            canvasPoint.x, canvasPoint.y, this._scale, this._scale)
                        break
                    }
                    case C.TilesetBlock: {
                        this._context.drawImage(tileset, canvasPoint.x, canvasPoint.y, this._scale, this._scale)
                        break
                    }
                }
            }
        }
    }

    private renderObjects() {
        const scalar            = this._scale / C.CellSizePixels

        const charWidth         = C.FontWidth           * scalar
        const charHeight        = C.FontHeight          * scalar
        const singleX           = C.CellSingleX         * scalar
        const doubleX1          = C.CellDoubleX1        * scalar
        const doubleX2          = C.CellDoubleX2        * scalar
        const integerY          = C.CellIntegerY        * scalar
        const fractionY         = C.CellFractionY       * scalar
        const fractionHeight    = C.FractionHeight      * scalar
        const numeratorY        = C.CellNumeratorY      * scalar
        const denominatorY      = C.CellDenominatorY    * scalar
        const fraction1Width    = C.Fraction1Width      * scalar
        const fraction2Width    = C.Fraction2Width      * scalar
        const minusXSingle      = C.CellMinusXSingle    * scalar
        const minusXDouble      = C.CellMinusXDouble    * scalar
        const minusWidth        = C.MinusWidth          * scalar

        const types             = this._world.objects
        const connections       = this._world.objectConnections
        const ports             = this._world.objectPorts
        const data              = this._world.objectData

        for (let i = 0; i < C.WorldWidthCells; i++) {
            for (let j = 0; j < C.WorldHeightCells; j++) {
                const type = types[i][j]
                if (type === C.TypeEmpty) continue

                const point         = new Point(i, j)
                const canvasPoint   = this.canvasPoint(point)
                const tileset       = I.TypeToTileset.get(type)!

                switch (C.TypeToTileset[type]) {
                    case C.TilesetConnected: {
                        this._context.drawImage(tileset, 
                            connections[i][j] * C.CellSizePixels, 0, C.CellSizePixels, C.CellSizePixels, 
                            canvasPoint.x, canvasPoint.y, this._scale, this._scale)
                        break
                    }
                    case C.TilesetBlock: {
                        this._context.drawImage(tileset, canvasPoint.x, canvasPoint.y, this._scale, this._scale)
                        break
                    }
                    case C.TilesetOrthogonal: {
                        this._context.drawImage(tileset, 
                            ports[i][j] * C.CellSizePixels, 0, C.CellSizePixels, C.CellSizePixels, 
                            canvasPoint.x, canvasPoint.y, this._scale, this._scale)
                        break
                    }
                    case C.TilesetIO: {
                        this._context.drawImage(tileset, 
                            ports[i][j] * C.CellSizePixels, 0, C.CellSizePixels, C.CellSizePixels, 
                            canvasPoint.x, canvasPoint.y, this._scale, this._scale)
                        break
                    }
                    case C.TilesetBinary: {
                        this._context.drawImage(tileset, 
                            ports[i][j] * C.CellSizePixels, 0, C.CellSizePixels, C.CellSizePixels, 
                            canvasPoint.x, canvasPoint.y, this._scale, this._scale)
                        break
                    }
                }

                const value = data[i][j]

                if (value.length === 1) {
                    const charCode  = value.charCodeAt(0)
                    const srcX      = C.FontWidth * charCode
                    const dstX      = canvasPoint.x + singleX
                    const dstY      = canvasPoint.y + integerY
                    this._context.drawImage(I.Font, 
                        srcX, 0, C.FontWidth, C.FontHeight, 
                        dstX, dstY, charWidth, charHeight)
                    continue
                }

                switch (this.dataType(value)) {
                    case C.DataBoolean: {
                        const length    = value.length
                        const x         = (this._scale - charWidth * length) / 2
                        for (let i = 0; i < length; i++) {
                            const charCode  = value.charCodeAt(i)
                            const srcX      = C.FontWidth * charCode
                            const dstX      = canvasPoint.x + x + charWidth * i
                            const dstY      = canvasPoint.y + integerY
                            this._context.drawImage(I.Font, 
                                srcX, 0, C.FontWidth, C.FontHeight, 
                                dstX, dstY, charWidth, charHeight)
                        }
                        break
                    }
                    case C.DataInteger: {
                        const negative      = value[0] === '-'
                        const absoluteValue = negative ? value.substring(1) : value
                        const width         = absoluteValue.length
                        const dstY          = canvasPoint.y + integerY
                        if (width === 1) {
                            const srcX = C.FontWidth * absoluteValue.charCodeAt(0)
                            const dstX = canvasPoint.x + singleX
                            this._context.drawImage(I.Font, srcX, 0, C.FontWidth, C.FontHeight, dstX, dstY, charWidth, charHeight)
                        } else {
                            const srcX1 = C.FontWidth * absoluteValue.charCodeAt(0)
                            const srcX2 = C.FontWidth * absoluteValue.charCodeAt(1)
                            const dstX1 = canvasPoint.x + doubleX1
                            const dstX2 = canvasPoint.x + doubleX2
                            this._context.drawImage(I.Font, srcX1, 0, C.FontWidth, C.FontHeight, dstX1, dstY, charWidth, charHeight)
                            this._context.drawImage(I.Font, srcX2, 0, C.FontWidth, C.FontHeight, dstX2, dstY, charWidth, charHeight)
                        }

                        if (negative) {
                            const dstX = canvasPoint.x + (width === 1 ? minusXSingle : minusXDouble)
                            const dstY = canvasPoint.y + fractionY
                            this._context.drawImage(I.MinusSign, dstX, dstY, minusWidth, fractionHeight)
                        }
                        break
                    }
                    case C.DataRational: {
                        const fractionIndex = value.indexOf('/')
                        const negative      = value[0] === '-'
                        const numerator     = negative ? value.substring(1, fractionIndex) : value.substring(0, fractionIndex)
                        const denominator   = value.substring(fractionIndex + 1)
                        const width         = Math.max(numerator.length, denominator.length)
                        const numY          = canvasPoint.y + numeratorY
                        const denY          = canvasPoint.y + denominatorY

                        if (width === 1) {
                            const dstX = canvasPoint.x + singleX
                            const dstY = canvasPoint.y + fractionY
                            this._context.drawImage(I.Fraction1, dstX, dstY, fraction1Width, fractionHeight)
                        } else {
                            const dstX = canvasPoint.x + doubleX1
                            const dstY = canvasPoint.y + fractionY
                            this._context.drawImage(I.Fraction2, dstX, dstY, fraction2Width, fractionHeight)
                        }

                        if (numerator.length === 1) {
                            const srcX = C.FontWidth * numerator.charCodeAt(0)
                            const dstX = canvasPoint.x + singleX
                            this._context.drawImage(I.Font, srcX, 0, C.FontWidth, C.FontHeight, dstX, numY, charWidth, charHeight)
                        } else {
                            const srcX1 = C.FontWidth * numerator.charCodeAt(0)
                            const srcX2 = C.FontWidth * numerator.charCodeAt(1)
                            const dstX1 = canvasPoint.x + doubleX1
                            const dstX2 = canvasPoint.x + doubleX2
                            this._context.drawImage(I.Font, srcX1, 0, C.FontWidth, C.FontHeight, dstX1, numY, charWidth, charHeight)
                            this._context.drawImage(I.Font, srcX2, 0, C.FontWidth, C.FontHeight, dstX2, numY, charWidth, charHeight)
                        }

                        if (denominator.length === 1) {
                            const srcX = C.FontWidth * denominator.charCodeAt(0)
                            const dstX = canvasPoint.x + singleX
                            this._context.drawImage(I.Font, srcX, 0, C.FontWidth, C.FontHeight, dstX, denY, charWidth, charHeight)
                        } else {
                            const srcX1 = C.FontWidth * denominator.charCodeAt(0)
                            const srcX2 = C.FontWidth * denominator.charCodeAt(1)
                            const dstX1 = canvasPoint.x + doubleX1
                            const dstX2 = canvasPoint.x + doubleX2
                            this._context.drawImage(I.Font, srcX1, 0, C.FontWidth, C.FontHeight, dstX1, denY, charWidth, charHeight)
                            this._context.drawImage(I.Font, srcX2, 0, C.FontWidth, C.FontHeight, dstX2, denY, charWidth, charHeight)
                        }

                        if (negative) {
                            const dstX = canvasPoint.x + (width === 1 ? minusXSingle : minusXDouble)
                            const dstY = canvasPoint.y + fractionY
                            this._context.drawImage(I.MinusSign, dstX, dstY, minusWidth, fractionHeight)
                        }

                        break
                    }
                    case C.DataOperator: {
                        const length    = value.length
                        const x         = (this._scale - charWidth * length) / 2
                        for (let i = 0; i < length; i++) {
                            const charCode  = value.charCodeAt(i)
                            const srcX      = C.FontWidth * charCode
                            const dstX      = canvasPoint.x + x + charWidth * i
                            const dstY      = canvasPoint.y + integerY
                            this._context.drawImage(I.Font, 
                                srcX, 0, C.FontWidth, C.FontHeight, 
                                dstX, dstY, charWidth, charHeight)
                        }
                        break
                    }
                }
            }
        }
    }

    private renderHighlights(types: Array<Uint8Array>) {
        for (let i = 0; i < C.WorldWidthCells; i++) {
            for (let j = 0; j < C.WorldHeightCells; j++) {
                const type = types[i][j]
                if (type === C.TypeEmpty) continue
                const point         = new Point(i, j)
                const canvasPoint   = this.canvasPoint(point)
                this._context.drawImage(I.Highlight, canvasPoint.x, canvasPoint.y, this._scale, this._scale)
            }
        }
    }

    private renderInspector() {
        const displayPoint = this.canvasPoint(this._inspectCell)
        this._context.strokeStyle = 'white'
        this._context.lineWidth = this._scale * 0.03125
        this._context.strokeRect(displayPoint.x, displayPoint.y, this._scale, this._scale)
    }
    private renderHover() {
        const hoverCell = this.cellPoint(this._gamePoint)
        const displayPoint = this.canvasPoint(hoverCell)
        this._context.fillStyle = '#ffffff20'
        this._context.fillRect(displayPoint.x, displayPoint.y, this._scale, this._scale)
    }
    private renderConnections() {
        const type = this.type()
        switch (this.layer()) {
            case C.LayerFloor: {
                this.renderLayerConnections(this._world.floor)
                break
            }
            case C.LayerObject: {
                this.renderLayerConnections(this._world.objects)
                break
            }
            case C.LayerRoof: {
                this.renderLayerConnections(this._world.roof)
                break
            }
        }
    }
    private renderLayerConnections(types: Array<Uint8Array>) {
        this._context.fillStyle = 'rgba(255, 255, 255, 0.25)'
        const half = this._scale / 2
        const sixth = this._scale * C.ConnectionScalar
        this._context.beginPath()
        for (let i = 0; i < C.WorldWidthCells; i++) {
            for (let j = 0; j < C.WorldHeightCells; j++) {
                const type = types[i][j]
                if (type === C.TypeEmpty) continue
                if (C.TypeToTileset[type] !== C.TilesetConnected) continue

                const e     = type === types[i + 1][j]
                const s     = type === types[i][j + 1]
                const se    = type === types[i + 1][j + 1]
                const p     = this.canvasPoint(new Point(i, j))

                if (e) {
                    const x = p.x + this._scale
                    const y = p.y + half
                    this._context.moveTo(x, y)
                    this._context.arc(x, y, sixth, 0, C.Tau)
                }
                if (s) {
                    const x = p.x + half
                    const y = p.y + this._scale
                    this._context.moveTo(x, y)
                    this._context.arc(x, y, sixth, 0, C.Tau)
                }
                if (e && s && se) {
                    const x = p.x + this._scale
                    const y = p.y + this._scale
                    this._context.moveTo(x, y)
                    this._context.arc(x, y, sixth, 0, C.Tau)
                }
            }
        }
        this._context.fill()
    }


    private gamePoint(canvasPoint: Point): Point {
        const x = this._focus.x + (canvasPoint.x - this._canvas.offsetWidth / 2) / this._scale
        const y = this._focus.y + (canvasPoint.y - this._canvas.offsetHeight / 2) / this._scale
        return new Point(x, y)
    }
    private cellPoint(gamePoint: Point): Point {
        const x = Math.floor(gamePoint.x)
        const y = Math.floor(gamePoint.y)
        return new Point(x, y)
    }
    private canvasPoint(gamePoint: Point) {
        const x = this._canvas.offsetWidth / 2 + this._scale * (gamePoint.x - this._focus.x)
        const y = this._canvas.offsetHeight / 2 + this._scale * (gamePoint.y - this._focus.y)
        return new Point(x, y)
    }
}

new Editor()