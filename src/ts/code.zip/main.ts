import Game from './game.js'

const game: Game = new Game()