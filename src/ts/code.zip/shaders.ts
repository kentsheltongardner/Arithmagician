// Create given shader code, a canvas, and uniforms, apply a shader

export default class Shader {
    private _fragmentProgram: string
    constructor(fragmentProgram: string) {
        this._fragmentProgram = fragmentProgram
    }
}

