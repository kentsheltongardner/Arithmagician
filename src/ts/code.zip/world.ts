import * as C from './constants.js'

// save and retrieve data as uint8array



export default class World {
    public floor: Array<Uint8Array>                 = new Array(C.WorldWidthCells)
    public floorConnections: Array<Uint8Array>      = new Array(C.WorldWidthCells)
    public objects: Array<Uint8Array>               = new Array(C.WorldWidthCells)
    public objectConnections: Array<Uint8Array>     = new Array(C.WorldWidthCells)
    public objectData: Array<Array<string>>         = new Array(C.WorldWidthCells)
    public objectPorts: Array<Uint8Array>           = new Array(C.WorldWidthCells)
    public objectFlags: Array<Uint8Array>           = new Array(C.WorldWidthCells)
    public roof: Array<Uint8Array>                  = new Array(C.WorldWidthCells)
    public roofConnections: Array<Uint8Array>       = new Array(C.WorldWidthCells)


    constructor() {
        for (let i = 0; i < C.WorldWidthCells; i++) {
            this.floor[i]               = new Uint8Array(C.WorldHeightCells)
            this.floorConnections[i]    = new Uint8Array(C.WorldHeightCells)
            this.objects[i]             = new Uint8Array(C.WorldHeightCells)
            this.objectConnections[i]   = new Uint8Array(C.WorldHeightCells)
            this.objectData[i]          = new Array<string>(C.WorldHeightCells)
            this.objectPorts[i]         = new Uint8Array(C.WorldHeightCells)
            this.objectFlags[i]         = new Uint8Array(C.WorldHeightCells)
            this.roof[i]                = new Uint8Array(C.WorldHeightCells)
            this.roofConnections[i]     = new Uint8Array(C.WorldHeightCells)
        }

        for (let i = 0; i < C.WorldWidthCells; i++) {
            for (let j = 0; j < C.WorldHeightCells; j++) {
                this.objectData[i][j] = ''
            }
        }
    }



    // private messages: Message
    // private historyStack

    // private strength: number // Positive infinity upgrade
    // private light: boolean // Lights up dungeon and mine regions
    // private grab: boolean // While grabbing the player does not change direction, player can grab nothing
    // private reach: boolean // Grab objects at a distance
    // private blink: boolean // Turn into light and move as far as possible
    // private shield: boolean // 
    // private swap: boolean // 

    // // Local, session based history? 

    // constructor() {

    // }
    // public load(json: string) {
        
    // }
    // public save(): string {

    // }
    // save / load
}