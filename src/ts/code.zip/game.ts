import FPSTracker from './fps.js'
import InputManager from './input.js'
import Rect from './rect.js'
import * as Constants from './constants.js'

export default class Game {
    private _fpsTracker:    FPSTracker
    private _inputManager:  InputManager
    private _canvas:        HTMLCanvasElement
    private _context:       CanvasRenderingContext2D

    constructor() {
        this._canvas    = <HTMLCanvasElement>document.getElementById('game-canvas')
        this._context   = <CanvasRenderingContext2D>this._canvas.getContext('2d')
        this._inputManager  = new InputManager()
        this._fpsTracker    = new FPSTracker(120)
        this._fpsTracker.start()

        window.addEventListener('keydown', event => { this.keyDownHandler(event) }, false)
        window.addEventListener('keyup', event => { this.keyUpHandler(event) }, false)

        this.loop()
    }

    private keyDownHandler(event: KeyboardEvent) {
        this._inputManager.keyDown(event)
    }
    private keyUpHandler(event: KeyboardEvent) {
        this._inputManager.keyUp(event)
    }

    private loop() {
        this._fpsTracker.tick()

        this._canvas.width = window.innerWidth
        this._canvas.height = window.innerHeight

        this._context.clearRect(0, 0, this._canvas.width, this._canvas.height)

        const rect = Game.gameRect()
        this._context.fillStyle = '#202020'
        this._context.fillRect(rect.x, rect.y, rect.w, rect.h)

        const size = Game.cellSize()
        this._context.fillStyle = '#404040'
        for (let i = 0; i < Constants.DisplayWidthCells; i++) {
            for (let j = 0; j < Constants.DisplayHeightCells; j++) {
                if ((i + j) % 2 === 0) {
                    const x = rect.x + i * size
                    const y = rect.y + j * size
                    this._context.fillRect(x, y, size, size)
                }
            }
        }

        const fps = this._fpsTracker.fps
        const fpsString = fps.toLocaleString("en-US", { maximumFractionDigits: 2, minimumFractionDigits: 2 })
        this._context.font = '20px sans-serif'
        this._context.fillStyle = '#ffffff20'
        this._context.fillText(`FPS: ${ fpsString }`, 10, 30)

        requestAnimationFrame(() => { this.loop() })
    }

    private static horizontalDisplay(): boolean {
        return window.innerWidth * Constants.DisplayHeightCells > window.innerHeight * Constants.DisplayWidthCells
    }
    private static cellSize(): number {
        if (Game.horizontalDisplay()) {
            return Math.floor(window.innerHeight / Constants.DisplayHeightCells)
        }
        return Math.floor(window.innerWidth / Constants.DisplayWidthCells)
    }
    private static gameRect(): Rect {
        const size = Game.cellSize()
        const w: number = size * Constants.DisplayWidthCells
        const h: number = size * Constants.DisplayHeightCells
        const x: number = Math.floor((window.innerWidth - w) / 2)
        const y: number = Math.floor((window.innerHeight - h) / 2)
        return new Rect(x, y, w, h)
    }
}

new Game()