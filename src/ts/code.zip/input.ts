import Vector from "./vector.js"
import Vectors from "./vectors.js"

export default class InputManager {
    private static readonly _directionMap = new Map<string, Vector>([
        ['ArrowRight', Vectors.East],
        ['ArrowDown', Vectors.South],
        ['ArrowLeft', Vectors.West],
        ['ArrowUp', Vectors.North]
    ])

    private _directions: Array<string>
    private _grabPressed: boolean

    constructor() {
        this._directions = []
        this._grabPressed = false
    }
    public keyDown(event: KeyboardEvent) {
        if (event.code === 'Space') {
            this._grabPressed = true
        } else if (InputManager._directionMap.has(event.code)
                && this._directions.indexOf(event.code) === -1) {
            this._directions.push(event.code)
        }
    }
    public keyUp(event: KeyboardEvent) {
        if (event.code === 'Space') {
            this._grabPressed = false
        } else if (InputManager._directionMap.has(event.code)) {
            const index = this._directions.indexOf(event.code)
            if (index !== -1) {
                this._directions.splice(index, 1)
            }
        }
    }
    public direction(): Vector {
        const length = this._directions.length
        if (length === 0) {
            return Vectors.Zero
        }
        const code = this._directions[length - 1]
        return InputManager._directionMap.get(code)!
    }
    public grabPressed(): boolean { return this._grabPressed }
}