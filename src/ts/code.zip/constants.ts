import Rect from "./rect.js"

//  #####   #######  #     #  #######  ######      #     #        
// #     #  #        ##    #  #        #     #    # #    #        
// #        #        # #   #  #        #     #   #   #   #        
// #        ####     #  #  #  ####     ######   #######  #        
// #   ###  #        #   # #  #        #   #    #     #  #        
// #     #  #        #    ##  #        #    #   #     #  #        
//  #####   #######  #     #  #######  #     #  #     #  #######  

export const Tau                    = Math.PI * 2
export const FontWidth              = 8
export const FontHeight             = 14
export const FontPaddingTop         = 1
export const FontPaddingBottom      = 2
export const FractionHeight         = 4
export const Fraction1Width         = FontWidth
export const Fraction2Width         = FontWidth * 2
export const MinusWidth             = 6
export const WorldWidthCells        = 256
export const WorldHeightCells       = 256
export const WorldSizeCells         = WorldWidthCells * WorldHeightCells
export const WorldRectCells         = new Rect(0, 0, WorldWidthCells, WorldHeightCells)
export const InnerWorldRectCells    = new Rect(1, 1, WorldWidthCells - 2, WorldHeightCells - 2)
export const CellSizePixels         = 60
export const DisplayWidthCells      = 16
export const DisplayHeightCells     = 9
export const DisplayWidthPixels     = DisplayWidthCells * CellSizePixels
export const DisplayHeightPixels    = DisplayHeightCells * CellSizePixels
export const ZoomInFactor           = 8 / 7
export const ZoomOutFactor          = 7 / 8
export const ConnectionScalar       = 0.2

export const CellSingleX            = (CellSizePixels - FontWidth) / 2
export const CellDoubleX1           = CellSizePixels / 2 - FontWidth
export const CellDoubleX2           = CellSizePixels / 2
export const CellIntegerY           = (CellSizePixels - FontHeight) / 2
export const CellFractionY          = (CellSizePixels - FractionHeight) / 2
export const CellNumeratorY         = CellFractionY - 1 - FontHeight + FontPaddingBottom
export const CellDenominatorY       = CellFractionY + FractionHeight + 1 - FontPaddingTop
export const CellMinusXSingle       = CellSingleX - 1 - MinusWidth
export const CellMinusXDouble       = CellDoubleX1 - 1 - MinusWidth

// #######  #     #  ######   #######   #####   
//    #      #   #   #     #  #        #     #  
//    #       # #    #     #  #        #        
//    #        #     ######   ####      #####   
//    #        #     #        #              #  
//    #        #     #        #        #     #  
//    #        #     #        #######   #####   

export const TypeEmpty              = 0
export const TypeGoldWall           = 1
export const TypeBlueTile           = 2
export const TypeSlateTile          = 3
export const TypeCrate              = 4
export const TypeBars               = 5
export const TypeBinding            = 6
export const TypeGlass              = 7
export const TypeStoneHead          = 8
export const TypePiping             = 9
export const TypeUnaryOperator      = 10
export const TypeBinaryOperator     = 11
export const TypeGate               = 12
export const TypeDefinition         = 13
export const TypeConstant           = 14
export const TypeVariable           = 15

export const TilesetNone            = 0
export const TilesetConnected       = 1 // Standard tiling
export const TilesetBlock           = 2 // Single image
export const TilesetOrthogonal      = 3 // Can face 4 directions
export const TilesetIO              = 4 // Each direction can be none, in 1, in2, or out
export const TilesetBinary          = 5 // Each direction can be t/f

export const TilesetHorizontal      = 5 // Connects to horizontal neighbors
export const TilesetVertical        = 6 // Connects to vertical neighbors
export const TilesetOctilinear      = 7 // Can point in 8 directions
export const TilesetDiagonal        = 8 // Can point in diagonal directions

export const CharCodeA              = 'a'.charCodeAt(0)
export const CharCodeZ              = 'z'.charCodeAt(0)
export const CharCode0              = '0'.charCodeAt(0)
export const CharCode9              = '9'.charCodeAt(0)

export const TypeToTileset: number[] = [
    TilesetNone,
    TilesetConnected,
    TilesetConnected,
    TilesetConnected,
    TilesetConnected,
    TilesetConnected,
    TilesetConnected,
    TilesetConnected,
    TilesetBlock,
    TilesetConnected,
    TilesetIO,
    TilesetIO,
    TilesetBlock,
    TilesetOrthogonal,
    TilesetBinary,
    TilesetBinary,
]
export const StringToType: { [key: string]: number } = {
    TypeEmpty:          TypeEmpty,
    TypeGoldWall:       TypeGoldWall,
    TypeBlueTile:       TypeBlueTile,
    TypeSlateTile:      TypeSlateTile,
    TypeCrate:          TypeCrate,
    TypeBars:           TypeBars,
    TypeBinding:        TypeBinding,
    TypeGlass:          TypeGlass,
    TypeStoneHead:      TypeStoneHead,
    TypePiping:         TypePiping,
    TypeUnaryOperator:  TypeUnaryOperator,
    TypeBinaryOperator: TypeBinaryOperator,
    TypeGate:           TypeGate,
    TypeDefinition:     TypeDefinition,
    TypeConstant:       TypeConstant,
    TypeVariable:       TypeVariable,
}

export const TypeToString: string[] = [
    'TypeEmpty',
    'TypeGoldWall',
    'TypeBlueTile',
    'TypeSlateTile',
    'TypeCrate',
    'TypeBars',
    'TypeBinding',
    'TypeGlass',
    'TypeStoneHead',
    'TypePiping',
    'TypeOperator',
    'TypeGate',
    'TypeDefinition',
]

// #           #     #     #  #######  ######    #####   
// #          # #     #   #   #        #     #  #     #  
// #         #   #     # #    #        #     #  #        
// #        #######     #     ####     ######    #####   
// #        #     #     #     #        #   #          #  
// #        #     #     #     #        #    #   #     #  
// #######  #     #     #     #######  #     #   #####   

export const LayerNone      = 0
export const LayerFloor     = 1
export const LayerObject    = 2
export const LayerRoof      = 3
export const StringToLayer: { [key: string]: number } = {
    LayerNone:      LayerNone,
    LayerFloor:     LayerFloor,
    LayerObject:    LayerObject,
    LayerRoof:      LayerRoof,
}
export const LayerToString: string[] = [
    'LayerNone',
    'LayerFloor',
    'LayerObject',
    'LayerRoof',
]

//    #      #####   #######  #######   #####   #     #   #####   
//   # #    #     #     #        #     #     #  ##    #  #     #  
//  #   #   #           #        #     #     #  # #   #  #        
// #######  #           #        #     #     #  #  #  #   #####   
// #     #  #           #        #     #     #  #   # #        #  
// #     #  #     #     #        #     #     #  #    ##  #     #  
// #     #   #####      #     #######   #####   #     #   #####   

export const ActionBuild            = 0
export const ActionConnect          = 1
export const ActionInspect          = 2
export const ActionSelect           = 3
export const StringToAction: { [key: string]: number } = {
    ActionBuild:    ActionBuild,
    ActionConnect:  ActionConnect,
    ActionInspect:  ActionInspect,
    ActionSelect:   ActionSelect,
}
export const ActionToString: string[] = [
    'ActionBuild',
    'ActionConnect',
    'ActionInspect',
    'ActionSelect',
]

// ######   #######  #######   #####   
// #     #     #        #     #     #  
// #     #     #        #     #        
// ######      #        #      #####   
// #     #     #        #           #  
// #     #     #        #     #     #  
// ######   #######     #      #####   

export const BitsNone       = 0b00000000
export const BitsEast       = 0b00000001
export const BitsSouth      = 0b00000010
export const BitsWest       = 0b00000100
export const BitsNorth      = 0b00001000
export const BitsSoutheast  = 0b00010000
export const BitsSouthwest  = 0b00100000
export const BitsNorthwest  = 0b01000000
export const BitsNortheast  = 0b10000000

export const PortNone       = 0b00000000
export const PortInOne      = 0b00000001
export const PortInTwo      = 0b00000010
export const PortOut        = 0b00000011

// #######  #     #  #     #   #####   #######  #######   #####   #     #   #####   
// #        #     #  ##    #  #     #     #        #     #     #  ##    #  #     #  
// #        #     #  # #   #  #           #        #     #     #  # #   #  #        
// ####     #     #  #  #  #  #           #        #     #     #  #  #  #   #####   
// #        #     #  #   # #  #           #        #     #     #  #   # #        #  
// #        #     #  #    ##  #     #     #        #     #     #  #    ##  #     #  
// #         #####   #     #   #####      #     #######   #####   #     #   #####   

export const UnaryOperatorStrings = new Set<string>()
UnaryOperatorStrings.add('')
UnaryOperatorStrings.add('-')
UnaryOperatorStrings.add('not')

export const BinaryOperatorStrings = new Set<string>()
BinaryOperatorStrings.add('+')
BinaryOperatorStrings.add('-')
BinaryOperatorStrings.add('*')
BinaryOperatorStrings.add('/')
BinaryOperatorStrings.add('=')
BinaryOperatorStrings.add('and')
BinaryOperatorStrings.add('or')

export const DataNone       = 0
export const DataBoolean    = 1
export const DataInteger    = 2
export const DataRational   = 3
export const DataVariable   = 4
export const DataOperator   = 5
export const DataGeneral    = 6