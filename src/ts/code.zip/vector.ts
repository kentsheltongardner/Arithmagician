export default class Vector {
    public dx: number
    public dy: number

    constructor(dx: number, dy: number) {
        this.dx = dx
        this.dy = dy
    }

    public oppositeVector() {
        return new Vector(-this.dx, -this.dy)
    }

    public scaledVector(scalar: number): Vector {
        return new Vector(this.dx * scalar, this.dy * scalar)
    }

    public equals(v: Vector): boolean {
        return v.dx === this.dx && v.dy === this.dy
    }
}